<template>
  <div>
    <div class="container">
        <div class="phone header_phone">
          <div class="header_modal">
            <router-link to="/businessusercenter/upgrade_business_account" class="header_arrow"><img src="img/header_arrow.png"></router-link>
            <a>BUSINESS AGREEMENT</a>
          </div>
          <div class="content left-content header_top">
            <p class="medium_title">Business Agreement</p>
            <p class="upgrade_gs_para">RECENT UPDATE: July 13, 201</p>
            <p class="upgrade_gs_para">This insertion order, between Golden Link Plus (GOLD) and Business, sets forth the rights and obligations of each party with respect to the social media marketing campaign described in this document. Business understands that the sole obligation of GOLD is to execute the referenced marketing campaign as described in this insertion order.</p>
            <p class="medium_1_title">1. PAYMENT</p>
            <p class="upgrade_gs_para">Business agrees to pay GOLD for all marketing offers published on GOLD, its assigns and/or GS marketer, on a CPA, CPC, CPS, CPL, CPI basis (Cost Per Acquisition or Cost Per Click, Cost Per Sale, Cost Per Lead, Cost Per installation in accordance with the terms of conditions on GOLD. All such actions, acquisitions, clicks, sales and/or other form of payable events herewith shall be referred to as “Actions”.<br>Business agrees to pay in advance for any business events and there will be no chargebacks allowed once the campaign is set up, and once the G-Coin promotions and rewards have been spent, then there is no chargeback.<br>Business knows and agrees, based upon the ad offer, if business is unable to provide conversion information, or intentionally deletes the tracking pixels; and/or GOLD’s tracking system fails to report Actions or reports less Actions than the actual amount, then business agrees to pay GOLD based on an estimate to be negotiated in good faith by the parties based on the data available to both parties.Business agrees to pay all costs incurred by GOLD including, but not limited to, collection agency and attorneys' fees and costs, as a result of having to enforce the terms of this insertion order.</p>

            <p class="medium_1_title">2. REPORTING</p>
            <p class="upgrade_gs_para">Reporting will be based on the number of Actions as shown by GOLD’s own tracking methods, typically a pixel placed on Business’s site.<br>Business understands there may be a discrepancy from time to time between their reporting system and GOLD. In such a case, GOLD agrees to provide detailed information on each discrepancy Action if such information exists, and Business agrees to pay for any Actions that contain sufficient information to qualify said Action as legitimate. In the event that Business and GOLD encounter any discrepancies, both parties agree to work diligently to resolve such items, and also agree to work together to address any technical issues so as to eliminate discrepancies in the future.  GOLD may accept changes material to campaign specific details only by accepting such terms in writing.</p>
            <p class="upgrade_gs_para"><b>FOR ALL LEAD GENERATION CAMPAIGNS:</b><br>A “valid lead'' depends upon both the post back information on GOLD, and once the prospect is contacted by Business, the prospect is interested in the service or product, this may be a valid lead. “Conversion rate” is based upon actual sales made by those prospects.<br>In the event that the Lead does not result in a conversion sale, then both parties (Business and GS) can provide their comments in their reviews - GOLD will maintain and display all relevant comments.  GOLD also reminds both parties to remember the importance of their online reputation.  In this way, all parties involved are promoting good marketing skills and business brand reputations.</p>

            <p class="medium_1_title">3. BUSINESS REPRESENTATIONS</p>
            <p class="upgrade_gs_para">Business represents and warrants that it holds required intellectual property rights and/or licenses to permit the use of advertising materials by GOLD and GOLD’s GS Marketers. Business warrants that its materials so provided to GOLD do not infringe on any third party's copyright, patent, trademark, trade secret or other proprietary rights; do not violate any law, statute, ordinance or regulation regarding the creation and marketing of online materials including, without limitation, those governing false and/or deceptive advertising; and are not defamatory or trade libelous in any way.</p>

            <p class="medium_1_title">4. ASSIGNMENT</p>
            <p class="upgrade_gs_para">Business will not assign this insertion order without GOLD's prior written consent. GOLD may assign all or a portion of its duties and obligations hereunder to any GS marketer, successor and/or other third party. Subject to the forgoing, terms of this insertion order will be fully binding upon, inure to the benefit of and be enforceable bt the parties' respective successors, heirs, executors, administrators and permitted assigns.</p>

            <p class="medium_1_title">5. CREATIVE CONTROL</p>
            <p class="upgrade_gs_para">Business will be solely responsible for creating, managing, editing, reviewing, cancelling and otherwise controlling the advertising banners, display creatives, text advertisements and other materials issued to GOLD. Business acknowledges that GOLD is acting only as a passive distributor of such content. GOLD has no obligation to Business regarding the content of advertisements Business places with GOLD. GOLD undertakes no responsibility to review the content, or any GS marketer-generated content, to determine whether any such content may result in liability to third parties.</p>

            <p class="medium_1_title">6. DISCLAIMER OF WARRANTIES</p>
            <p class="upgrade_gs_para">Both parties provide all services performed hereunder "AS IS'' and hereby expressly disclaim all warranties, expressed or implied, regarding their services or any portion thereof, including any implied warranty of merchantability or fitness for a particular purpose and implied warranties arising from course of dealing or course of performance. Without limiting the generality of the foregoing, both parties specifically disclaim any warranty regarding: (1) the number of individuals who will see the content; and (2) any benefits that the other party might obtain from the campaign. Neither party guarantees continuous or uninterrupted service to the campaign.</p>

            <p class="medium_1_title">7. LIMITATIONS ON LIABILITY</p>
            <p class="upgrade_gs_para">In no event shall either party be liable for any special, direct, indirect, incidental, actual, punitive or consequential damages, or for interrupted communications, lost data, lost revenue or lost profits arising out of, or in connection with this insertion order. Under no circumstances shall either party be liable to the other party or any third parties for an amount greater than the amounts received from Business pursuant to this insertion order.</p>

            <p class="medium_1_title">8. INDEMNITY</p>
            <p class="upgrade_gs_para">Business agrees to indemnify, defend, and hold harmless GOLD, its parents, successors, subsidiaries, and GS marketers, and their respective directors, officers, agents and employees for any claims, liabilities, costs and expenses (including reasonable attorney’s fees) made against GOLD by a third party or parties or a government agency as a result of: (i) any breach of the terms of this Agreement, including but not limited to the foregoing representations and warranties; (ii) any claim arising from the sale or license of Business’s goods or services; (iii) any violation of an applicable law, rule, or regulation by Business; or (iv) any other act, omission or misrepresentation by Business. GOLD agrees to indemnify, defend and hold harmless Business, its parents, successors, and subsidiaries, and their respective directors, officers, employees (the “Business Indemnified Parties”) for any claims, liabilities, costs and expenses (including reasonable attorney’s fees) made against the Business by a third party or parties as a result of acts of gross negligence or willful misconduct by GOLD. The indemnifying party may participate in the defense of the indemnified party at its own expense.</p>

            <p class="medium_1_title">9. CONFIDENTIAL INFORMATION</p>
            <p class="upgrade_gs_para">Neither Business nor GOLD shall disclose or use the other party’s confidential information for any purpose other than the purposes contemplated by this agreement, unless such disclosure or use is allowed by written permission of the other party. However, either party may disclose the other party’s confidential information to the extent required by applicable law, but only after five (5) days prior written notification to the other party of such required disclosure. Business’s confidential information shall remain the property of Business, and GOLD’s confidential information shall remain the property of GOLD. The parties shall not disclose any of the terms and conditions of this document to any third party without the express prior written consent of the other party.</p>

            <p class="medium_1_title">10. PRIVACY</p>
            <p class="upgrade_gs_para">Business warrants that engaging in the services provided by GOLD pursuant to this Insertion order shall not violate Business’s privacy policy, nor shall Business’s privacy policies conflict with GOLD’s privacy policies.   All parties represent and warrant that they are fully compliant with applicable privacy laws, and all federal and state regulations.  All parties shall also provide notice for, and fully disclose, their respective privacy policies and practices to visitors to their website(s).  Business agrees to and understands that anything voluntarily posted on the GOLD system by Business becomes public information.  Business agrees to follow all due diligence required in order to protect their private and/or confidential information at all times from any acts of disclosure.</p>

            <p class="medium_1_title">11. TERMINATION</p>
            <p class="upgrade_gs_para">If Business desires to terminate any campaign, or this entire agreement, then Business shall provide the following to GOLD:<br><b>A. </b>To terminate any campaign, first complete any pending obligations to GS for that campaign, do not make any new deposits, and inform GOLD in writing or via email that campaign is being terminated.<br><b>B. </b>Without any notice, then Business will need to make proper payments to affected GS Marketers, without any further dispute.<br><b>C. </b>In order to close each campaign/offer link, GOLD will charge a $10 fee for each link that is closed.<br>Business shall remain liable for all costs incurred prior to written termination.</p>

            <p class="medium_1_title">12. EMAIL SUPPRESSION LISTS</p>
            <p class="upgrade_gs_para">The parties hereby represent and warrant that they shall at all times fully comply with all applicable state and federal statutes, rules and regulations with respect to their respective businesses including, without limitation, CAN-SPAM and all other laws governing deceptive trade practices and/or online marketing and/or advertising. In the event that Business desires distribution of its campaigns via email, Business agrees to provide a regularly updated suppression list to GOLD containing current unsubscribe requests in conformance with CAN-SPAM. GOLD agrees to include a physical address for Business in the body of every email. Business must provide to GOLD its physical mailing address. If Business fails to provide such mailing address, GOLD will use the physical mailing address appearing in this insertion order.</p>

            <p class="medium_1_title">13. JURISDICTION</p>
            <p class="upgrade_gs_para">This Agreement shall be governed, construed, and enforced in accordance with the laws of the State of California, without regard to its conflict of laws rules. If any legal action is required to enforce this contract, such will be filed with a court in or near Los Angeles, California.  The parties are independent contractors and no agency, partnership, joint venture or employer-employee relationship is intended or created hereby. This insertion order sets forth the entire understanding and agreement of the parties and supersedes any and all prior oral or written agreements or understandings between the parties as to the subject matter and may be changed only by a subsequent writing signed by both parties. Unless otherwise stated, this insertion order is non-exclusive to either party and either party shall have the right to enter into similar agreements with other third parties. The parties hereby represent and warrant that they shall at all times fully comply with all applicable state and federal statutes, rules and regulations with respect to their respective businesses including, without limitation laws governing deceptive trade practices.</p>

            <p class="medium_1_title">14. MISCELLANEOUS</p>
            <p class="upgrade_gs_para">At no time shall business engage in any activity on the platform, or other related platforms, which is considered false, misleading, deceptive or malicious, this includes all posts, campaigns, or other comments written or verbal which serve to defraud either GOLD or other customers on the platform</p>

            <hr class="stage_date_money">
            <router-link to="/businessusercenter/upgrade_business_account">
              <button class="gs_account_stage_checkout_btn rotate_btn">
                <img src="reg_next.png" class="reg_next_rotate">Go Back
              </button>
            </router-link>
            
            
          </div>
        </div>
    </div>
  </div>
</template>
<script>

export default {
  name: "Business_Agreement",
  components: {
  },
  data () {
    return {
      
  }
  }
}
</script>
<style>
  .header_phone {
    position: relative;
  }
  .header_modal {
    position: fixed;
    height: 60px;
    background: white;
    width: 100%;
    max-width: 414px;
    opacity: 0.9;
  }
  .header_modal a {
    line-height: 60px;
    font-weight: 600;
    width: 100%;
    display: inline-block;
  }
  .header_top {
    margin: 80px 20px 20px 20px;
    border-radius: 12px;
    overflow: hidden;
    min-height: calc(100vh - 26px);
  }
  .header_top ul {
    padding: revert;
    list-style-type: disc;
    margin: 0 10px 0 0;
    font-size: 14px;
  }
  .header_arrow {
    text-align: left;
    margin-left: 22px;
    position: absolute;
  }
  .medium_title {
    margin: 20px 20px 10px 20px;
    font-weight: 600;
  }
  .medium_1_title {
    margin: 20px 20px 10px 20px;
    color: #EF8200;
  }

  .upgrade_gs_para {
    margin: 10px 20px;
    font-size: 14px;
  }
  .gs_account_stage_checkout_btn {
    color: white;
    background-color: #F4992D;
    width: calc(100% - 40px);
    margin: 0 20px;
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 20px;
  }
</style>
