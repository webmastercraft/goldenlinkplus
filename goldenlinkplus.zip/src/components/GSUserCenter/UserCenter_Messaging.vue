<template>
  <div>
    <div class="container">
        <div class="phone">
          <div class="content content_modal">
            <div class="close_btn">
              <router-link to="/usercenter"><i class="fa fa-times-circle" aria-hidden="true"></i></router-link>
            </div>
            
            <div class="account-title">
              Notifications (4)
            </div>
            <div class="notice_logo">
              <div>
              <img src="img/notice_logo.png">
              </div>
              <div class="notice_list">
              <p>Alice Hansen added you on her list</p>
              <p class="notice_time">4 hours ago</p>
              </div>
            </div>
            <div class="notice_logo">
              <div>
              <img src="img/notice_logo.png">
              </div>
              <div class="notice_list">
              <p>Alice Hansen added you on her list</p>
              <p class="notice_time">4 hours ago</p>
              </div>
            </div>
            <div class="notice_logo">
              <div>
              <img src="img/notice_logo.png">
              </div>
              <div class="notice_list">
              <p>Alice Hansen added you on her list</p>
              <p class="notice_time">4 hours ago</p>
              </div>
            </div>
            <div class="notice_logo">
              <div>
              <img src="img/notice_logo.png">
              </div>
              <div class="notice_list">
              <p>Alice Hansen added you on her list</p>
              <p class="notice_time">4 hours ago</p>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
</template>
<script>

export default {
  name: "Notifications",
  components: {
  }
}
</script>
<style>
  
</style>
