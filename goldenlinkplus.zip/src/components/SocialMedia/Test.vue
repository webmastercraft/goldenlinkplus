<template>
	<div>
		<p>Lorem ipsum. <span class="modal-trigger" data-modal-id="modal1">Click this trigger</span> to open a modal.</p>
	    <p>Close a modal by clicking off to the side, clicking the X, or pressing Escape.</p>
	    <div class="modal-wrapper" id="modal1">
	        <section class="modal-window">
	            <header class="modal-header">
	                <h3>Title goes here...</h3>
	                <div class="close-modal-button"></div>
	            </header>
	            <p>Congrats, you've opened a modal!</p>
	            <p>Now open <span class="modal-trigger" data-modal-id="modal2">another modal</span>!</p>
	        </section>
	    </div>
	    <div class="modal-wrapper" id="modal2">
	        <section class="modal-window">
	            <header class="modal-header">
	                <h3>Modalception 🤯</h3>
	                <div class="close-modal-button"></div>
	            </header>
	            <p>Noice.</p>
	        </section>
	    </div>
	</div>
</template>

<script>
export default {
  name: 'Test',
  components: {
  },
  mounted() {
		  	// Stack of modals
		let currentlyOpenModals = [];

		const noModalsOpen = () => !currentlyOpenModals.length;

		const openModal = modalId => {
		  const modalWrapper = document.getElementById(modalId);
		  modalWrapper.classList.add("visible");
		  currentlyOpenModals.push(modalWrapper);
		};

		// By definition, it's always the topmost. modal that will be closed first
		const closeTopmostModal = () => {
		  if (noModalsOpen()) {
		    return;
		  }

		  const modalWrapper = currentlyOpenModals[currentlyOpenModals.length - 1];
		  modalWrapper.classList.remove("visible");
		  currentlyOpenModals.pop();
		};

		const modalTriggers = document.querySelectorAll(".modal-trigger");
		modalTriggers.forEach(modalTrigger => {
		  modalTrigger.addEventListener("click", clickEvent => {
		    const trigger = clickEvent.target;
		    const modalId = trigger.getAttribute("data-modal-id");
		    openModal(modalId);
		  });
		});

		// Otherwise, clicking the content of a modal will propagate the click to the modal wrapper,
		// and that will close the entire thing. That's not what we want!
		document.querySelectorAll(".modal-window").forEach(modal => {
		  modal.addEventListener("click", clickEvent => {
		    clickEvent.stopPropagation();
		  });
		});

		const modalWrappers = document.querySelectorAll(".modal-wrapper");
		modalWrappers.forEach(modalWrapper => {
		  modalWrapper.addEventListener("click", () => {
		    closeTopmostModal();
		  });
		});

		document.querySelectorAll(".close-modal-button").forEach(closeModalButton => {
		  closeModalButton.addEventListener("click", () => {
		    closeTopmostModal();
		  });
		});

		document.body.addEventListener("keyup", keyEvent => {
		  if (keyEvent.key === "Escape") {
		    closeTopmostModal();
		  }
		});
  }
}
	
</script>
<style>
/*	* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    align-items: center;
    display: flex;
    flex-direction: column;
    font-family: Arial;
    font-size: 18px;
    height: 100vh;
    justify-content: center;
}

p {
    margin-bottom: 1em;
}*/

.modal-wrapper {
    align-items: center;
    background-color: rgba(100, 100, 100, 0.5);
    bottom: 0;
    display: flex;
    flex-wrap: wrap;
    height: 100vh;
    justify-content: center;
    left: 0;
    opacity: 0;
    position: fixed;
    right: 0;
    transition: all 0.2s ease-in-out;
    visibility: hidden;
    max-width: 414px;
    width: 100%;
    z-index: 1000;
    margin: auto;
}

.modal-wrapper.visible {
    opacity: 1;
    visibility: visible;
}

.modal-window {
    background-color: white;
    border-radius: 5px;
    box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
    padding: 20px;
    transform: scale(0);
    transition: 0.2s ease-in-out all;
    width: calc(100% - 40px);
    margin: 0 20px;
}

.modal-wrapper.visible .modal-window {
    transform: scale(1);
}

.modal-header {
    align-items: center;
    border-bottom: 2px solid black;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 20px;
}

.close-modal-button {
    align-items: center;
    cursor: pointer;
    display: flex;
    height: 30px;
    justify-content: center;
    width: 30px;
}

.close-modal-button::before {
    content: "X";
    color: rgb(112, 112, 112);
}

.close-modal-button:hover::before {
    color: black;
}

.modal-trigger, a {
    color: rgb(10, 47, 255);
    cursor: pointer;
    text-decoration: underline;
}

</style>