<template>
  <div>
    <div class="container">
      <div class="phone sociallogin">
        
          <div class="main_audio_modal">
            <div>
              <router-link to="/"><img src="main_logo.png" class="main_logo"></router-link>
              <router-link to="/socialmedia/socialmedia_messaging_messages"><img src="main_box.png" class="main_icon"></router-link>
              <img src="main_calendar.png" class="main_icon">
              <img src="main_contact.png" class="main_icon">
              <img src="main_user.png" class="main_user">
            </div>
            <p><img src="microphone.png" class="favicon_img">LIVE AUDIO EVENTS</p>
          </div>
          <div class="main_body main_body_audio">
            <div class="para_event">
              <div class="para_title">
                <p><img src="triangle.png" class="favicon_img">MAKING BIG TIME MONEY 101</p>
                <router-link to="/socialmedia/socialmedia_main_event_voice">
                  <p class="para_event_title">Let’s All win the Market!! asdf asd asdfsad</p>
                </router-link>
                <p>Arnold Swarzeneger<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Ben Hugh<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Alex Jackson<img src="msg_favicon.png" class="favicon_img_left"></p>
                <button>Join this Event</button>
              </div>
              <div class="para_group">
                <img src="Group_user.png">
                <p>
                  <img src="user_count.png">2501
                  <img src="msg_count.png">139
                </p>
              </div>
            </div>

            <div class="para_event">
              <div class="para_title">
                <p><img src="triangle.png" class="favicon_img">MAKING BIG TIME MONEY 101</p>
                <router-link to="/socialmedia/socialmedia_main_event_voice">
                  <p class="para_event_title">Let’s All win the Market!! asdf asd asdfsad</p>
                </router-link>
                <p>Arnold Swarzeneger<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Ben Hugh<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Alex Jackson<img src="msg_favicon.png" class="favicon_img_left"></p>
                <button>Join this Event</button>
              </div>
              <div class="para_group">
                <img src="Group_user.png">
                <p>
                  <img src="user_count.png">2501
                  <img src="msg_count.png">139
                </p>
              </div>
            </div>

            <div class="para_event">
              <div class="para_title">
                <p><img src="triangle.png" class="favicon_img">MAKING BIG TIME MONEY 101</p>
                <router-link to="/socialmedia/socialmedia_main_event_voice">
                  <p class="para_event_title">Let’s All win the Market!! asdf asd asdfsad</p>
                </router-link>
                <p>Arnold Swarzeneger<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Ben Hugh<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Alex Jackson<img src="msg_favicon.png" class="favicon_img_left"></p>
                <button>Join this Event</button>
              </div>
              <div class="para_group">
                <img src="Group_user.png">
                <p>
                  <img src="user_count.png">2501
                  <img src="msg_count.png">139
                </p>
              </div>
            </div>

            <div class="para_event">
              <div class="para_title">
                <p><img src="triangle.png" class="favicon_img">MAKING BIG TIME MONEY 101</p>
                <router-link to="/socialmedia/socialmedia_main_event_voice">
                  <p class="para_event_title">Let’s All win the Market!! asdf asd asdfsad</p>
                </router-link>
                <p>Arnold Swarzeneger<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Ben Hugh<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Alex Jackson<img src="msg_favicon.png" class="favicon_img_left"></p>
                <button>Join this Event</button>
              </div>
              <div class="para_group">
                <img src="Group_user.png">
                <p>
                  <img src="user_count.png">2501
                  <img src="msg_count.png">139
                </p>
              </div>
            </div>

            <div class="para_event">
              <div class="para_title">
                <p><img src="triangle.png" class="favicon_img">MAKING BIG TIME MONEY 101</p>
                <router-link to="/socialmedia/socialmedia_main_event_voice">
                  <p class="para_event_title">Let’s All win the Market!! asdf asd asdfsad</p>
                </router-link>
                <p>Arnold Swarzeneger<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Ben Hugh<img src="msg_favicon.png" class="favicon_img_left"></p>
                <p>Alex Jackson<img src="msg_favicon.png" class="favicon_img_left"></p>
                <button>Join this Event</button>
              </div>
              <div class="para_group">
                <img src="Group_user.png">
                <p>
                  <img src="user_count.png">2501
                  <img src="msg_count.png">139
                </p>
              </div>
            </div>
          </div>
          <div class="footer_background hallway_bottom">
            <div class="hallway_bottom">
              
              <span class="hallway_log">
                <img src="hallway_user.png">
                <span>+254 others</span>
              </span>

              <router-link to="/socialmedia/socialmedia_main_create_event"><button class="audio_circle_btn">Create Audio Event</button></router-link>

              <span class="hallway_icon">
                <img src="invite.png">
                <img src="mute.png">
              </span>

            </div>
          </div>
            
      </div>
    </div>
  </div>
</template>
<script>


export default {
  name: 'Event_Hallway',
  components: {
  }
}
</script>
<style>
  .hallway_bottom {
    background-image: none !important;
    border-radius: 30px 30px 0 0;
    display: flex;
    bottom: 0;
    width: 414px;
    height: 90px;
    background: white;
    position: fixed;
  }
  .hallway_log {
    width: 50%;
    display: flex;
    margin: 40px auto 0;
    padding-left: 20px;
  }
  .hallway_log img{
    width: 89px;
    height: 37px;
    float: left;
  }
  .hallway_log span {
    margin: auto;
    font-size: 13px;
    letter-spacing: 0.02em;
  }
  .hallway_icon {
    width: 50% !important;
    text-align: right !important;
    margin: 50px auto 0;
    padding-right: 20px;
  }
  .hallway_bottom button {
    bottom: 40px !important;
  }
  .hallway_icon img:first-child {
    margin: 0 20px;
  }
</style>
 