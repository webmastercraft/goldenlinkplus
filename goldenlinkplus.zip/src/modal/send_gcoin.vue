<template>
  <transition name="modal-fade">
    <div class="modal-backdrop">
      <div class="modal"
        role="dialog"
        aria-labelledby="modalTitle"
        aria-describedby="modalDescription"
      >
        <header
          class="modal-header"
          id="modalTitle"
        >
            <button
              type="button"
              class="close_btn"
              @click="close"
              aria-label="Close modal"
            >
              <i class="fa fa-times-circle" aria-hidden="true"></i>
            </button>
            <div class="connect_modal">
              <p class="coin_title">Send G-Coins </p>
              <hr class="coin_hr">
              <div class="event_mute_group">
                <div v-for="(item, index) in coindata" :key="index" class="mute_user">
                  
                  <div class="mute_icon">
                    <img :src="`${item.coin_image}`" class="mute_user_img">
                  </div>
                  <p class="coins_modal">{{item.coin}}</p>
                </div>
              </div>
              <hr class="coin_hr">
              <button class="send_coin_btn"><img src="modal_coin.png">115, 250</button>
              <button class="charge_coin_btn">Recharge<img src="sky_arrow.png"></button>
            </div>
        </header>
      </div>
    </div>
  </transition>
</template>

<script>

  export default {
    name: 'Send',
    data () {
      return {
        coindata: [
          {
          coin_image: "coin_10.png",
          coin: 10,
          },
          {
          coin_image: "coin_20.png",
          coin: 20,
          },
          {
          coin_image: "coin_50.png",
          coin: 50,
          },
          {
          coin_image: "coin_80.png",
          coin: 80,
          },
          {
          coin_image: "coin_100.png",
          coin: 100,
          },
          {
          coin_image: "coin_150.png",
          coin: 150,
          },
          {
          coin_image: "coin_180.png",
          coin: 180,
          },
          {
          coin_image: "coin_200.png",
          coin: 200,
          },
        ]
      }
    },
    methods: {
      close() {
        this.$emit('close');
      },
    },
  };
</script>
<style>
.coin_title {
  text-align: left !important;
  color: #EF8200;
  font-size: 18px;
  font-weight: 500;
}
.coin_hr {
  margin: 20px 0 !important;
}
.coins_modal {
  font-weight: 400;
  margin: 0 !important;
} 
.send_coin_btn {
  background-color: #FFB803;
  border-radius: 30px !important;
  color: white;
  padding: 5px 10px !important;
  margin: 0 !important;
  width: 125px !important;
  float: left;
}
.charge_coin_btn {
  border: 1px solid #13C8FF;
  color: #13C8FF;
  border-radius: 8px;
  padding: 5px 10px !important;
  margin: 0 !important;
  width: 125px !important;
  float: right;
}
.charge_coin_btn img {
  margin: 0 6px 1px !important;
}
</style>
