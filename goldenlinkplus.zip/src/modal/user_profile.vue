<template>
  <transition name="modal-fade">
    <div class="modal-backdrop">
      <div class="modal"
        role="dialog"
        aria-labelledby="modalTitle"
        aria-describedby="modalDescription"
      >
        <header
          class="modal-header"
          id="modalTitle"
        >
            <button
              type="button"
              class="close_btn"
              @click="close"
              aria-label="Close modal"
            >
              <i class="fa fa-times-circle" aria-hidden="true"></i>
            </button>
            <div class="user_profile">
              <p>For Development Purpose Only</p>
              <div class="host_profile">
                <button>Host view Co-host profile</button>
                <button>Host view Speaker profile</button>
                <button>Host view Audience profile</button>
                <button>Host view Self profile</button>
              </div>
              <div class="co_profile">
                <button>Co-host view Host profile</button>
                <button>Co-host view Co-host profile</button>
                <button>Co-host view Speaker profile</button>
                <button>Co-host view Audience profile</button>
                <button>Co-host view Self profile</button>
              </div>
              <div class="speaker_profile">
                <button>Co-host view Host profile</button>
                <button>Co-host view Co-host profile</button>
                <button>Co-host view Speaker profile</button>
                <button>Co-host view Audience profile</button>
                <button>Co-host view Self profile</button>
              </div>
              <div class="audience_profile">
                <button>Audience view Any Profile</button>
              </div>
            </div>
        </header>
      </div>
    </div>
  </transition>
</template>

<script>

  export default {
    name: 'User',
    data () {
      return {
        coindata: [
          {
          coin_image: "coin_10.png",
          coin: 10,
          },
          {
          coin_image: "coin_20.png",
          coin: 20,
          },
          {
          coin_image: "coin_50.png",
          coin: 50,
          },
          {
          coin_image: "coin_80.png",
          coin: 80,
          },
          {
          coin_image: "coin_100.png",
          coin: 100,
          },
          {
          coin_image: "coin_150.png",
          coin: 150,
          },
          {
          coin_image: "coin_180.png",
          coin: 180,
          },
          {
          coin_image: "coin_200.png",
          coin: 200,
          },
        ]
      }
    },
    methods: {
      close() {
        this.$emit('close');
      },
    },
  };
</script>
<style>
.user_profile {
  font-size: 16px;
}
.user_profile p {
  text-align: center;
  color: #70BCE5;
  margin: 0 0 10px;
}
.user_profile button {
  width: 100%;
  border-radius: 10px;
  padding: 5px 10px;
  margin: 3px 0;
  text-align: left;
}
.host_profile button{
  background-color: #E6F7FF;
  
}
.co_profile button{
  background-color: #FFF3E6;
}
.speaker_profile button{
  background-color: #E1FFD6;
}
.audience_profile button{
  background-color: #EEEBFF;
}
</style>
